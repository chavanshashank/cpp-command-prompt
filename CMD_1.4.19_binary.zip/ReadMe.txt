I have just created the Command Prompt�s few commands for my CMD using C++ for mini project. Still my CMD projects is in initial level and I am working to make it more and more better.! :) This is the version which compiled using the �Borland compiler 5.5?. As we are bit restricted to use this compiler for our programs.But I am sure it�s not very difficult to Convert it into ANSI C++ format. But I will update this project after some days with many new function of original Command Prompt.You can also download and use it on your Computer and if you have any ideas, suggestion or found any bug in my Program you can tell me or Contact me or Comment here.!

Please note that my project is in initial level, its code is not that optimized. But it works seamlessly though.! I will update it further with many new Functions and ANSI C++ standard functions as well.

For queries,suggestion or you found any problem , bug or improvements feel free to go at : http://www.pcosmos.com or 
e-mail me at : chavanshashank@outlook.com

_____________________________________
For best results kindly run this CMD as Administrator.
